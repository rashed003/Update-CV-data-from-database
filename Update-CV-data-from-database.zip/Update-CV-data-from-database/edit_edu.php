<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['update']))
{	
	$subject_or_group = $_POST['subject_or_group'];
    $date = $_POST['date'];
    $Institute_name = $_POST['Institute_name'];
	$address = $_POST['address'];
	$userId = $_SESSION['id'];
	
	// checking empty fields
	if(empty($subject_or_group) || empty($date) || empty($Institute_name) || empty($address)) {
				
		if(empty($subject_or_group)) {
			echo "<font color='red'>subject or group field is empty.</font><br/>";
		}
		
		if(empty($date)) {
			echo "<font color='red'>date field is empty.</font><br/>";
		}
		
		if(empty($Institute_name)) {
			echo "<font color='red'>Institute name field is empty.</font><br/>";
		}
        if(empty($address)) {
			echo "<font color='red'>address field is empty.</font><br/>";
		}		
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE edu SET subject_or_group='$subject_or_group', date='$date', Institute_name='$Institute_name', address='$address', WHERE id='$userId'");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: view_edu.php");
	}
}
?>
<?php
//getting id from url
$userId = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM edu WHERE id=$userId");

while($res = mysqli_fetch_array($result))
{
	$subject_or_group = $res['subject_or_group'];
	$date = $res['date'];
	$Institute_name = $res['Institute_name'];
    $address = $res['address'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	
	<form name="form1" method="post" action="edit_edu.php">
		<table border="0">
			<tr> 
				<td>subject or group</td>
				<td><input type="text" name="subject_or_group" value="<?php echo $subject_or_group;?>"></td>
			</tr>
			<tr> 
				<td>date</td>
				<td><input type="date" name="date" value="<?php echo $date;?>"></td>
			</tr>
			<tr> 
				<td>Institute_name</td>
				<td><input type="text" name="Institute_name" value="<?php echo $Institute_name;?>"></td>
			</tr>
            <tr> 
				<td>address</td>
				<td><input type="text" name="address" value="<?php echo $address;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
