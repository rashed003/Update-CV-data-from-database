<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add WORK EXPERIENCE Information</title>
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$company_name = $_POST['company_name'];
    $date = $_POST['date'];
	$possition = $_POST['possition'];
	$description = $_POST['description'];
	$userId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($company_name) || empty($date) || empty($possition) || empty($description)) {
				
		if(empty($company_name)) {
			echo "<font color='red'>company name field is empty.</font><br/>";
		}

        if(empty($date)) {
			echo "<font color='red'>date field is empty.</font><br/>";
		}
		
		if(empty($possition)) {
			echo "<font color='red'>possition field is empty.</font><br/>";
		}
		
		if(empty($description)) {
			echo "<font color='red'>description field is empty.</font><br/>";
		}

		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO exp(company_name, date, description, possition, user_id) VALUES('$company_name','$date','$description','$possition','$userId')");
		
		//display success message
		echo "<br><font color='green'>Data added successfully.<br>";
	}
}
?>



	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="exp.php" method="post" name="form1">
		<table width="25%" border="0">
			<br><h2>Add work experience informatios</h2><br>
			<tr>
				<td>company name</td>
				<td><input type="text" name="company_name"></td>
			</tr>
            <tr>
				<td>date</td>
				<td><input type="date" name="date"></td>
			</tr>
			<tr>
				<td>description</td>
				<td><input type="text" name="description"></td>
			</tr>
			<tr>
				<td>possition</td>
				<td><input type="text" name="possition"></td>
			</tr>
            <tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
			
		</table>
        
	</form>



</body>
</html>