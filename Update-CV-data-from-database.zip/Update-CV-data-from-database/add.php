<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Personal Information</title>
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$name = $_POST['name'];
    $email = $_POST['email'];
    $position = $_POST['position'];
	$phone = $_POST['phone'];
	$userId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($name) || empty($email) || empty($phone) || empty($position)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

        if(empty($email)) {
			echo "<font color='red'>email field is empty.</font><br/>";
		}
		
        if(empty($position)) {
			echo "<font color='red'>position field is empty.</font><br/>";
		}
		
		if(empty($phone)) {
			echo "<font color='red'>Phone field is empty.</font><br/>";
		}
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO cv(name, phone, position, email, user_id) VALUES('$name','$email','$phone','$position','$userId')");
		
		//display success message
		echo "<br><font color='green'>Data added successfully.<br>";
	}
}
?>



	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<br><h2>Add Personal Information</h2><br>
			<tr>
				<td>name</td>
				<td><input type="text" name="name"></td>
			</tr>
            <tr>
				<td>position</td>
				<td><input type="text" name="position"></td>
			</tr>
			<tr>
				<td>Phone</td>
				<td><input type="text" name="phone"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
            <tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
			
		</table>
        
	</form>



</body>
</html>