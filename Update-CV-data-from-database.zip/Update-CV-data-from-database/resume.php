<?php session_start(); ?>
<?php
  if(!isset($_SESSION['valid'])){
    header('Location: login.php');
  }
?>
<?php
    include("connection.php");
  $userId = $_SESSION['id'];
    $result = mysqli_query($mysqli, "SELECT * FROM cv WHERE user_id='$userId'")
					or die("Could not execute the select query.");

                    $res = mysqli_fetch_array($result);
$result2 = mysqli_query($mysqli, "SELECT * FROM exp WHERE user_id='$userId'")
					or die("Could not execute the select query.");

                    $res2 = mysqli_fetch_array($result2);
$result3 = mysqli_query($mysqli, "SELECT * FROM edu WHERE user_id='$userId'")
					or die("Could not execute the select query.");

                    $res3 = mysqli_fetch_array($result3);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css"
        integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <link rel="stylesheet" href="resume.css">
    <title>Resume</title>
</head>

<body>
    <div class="container">
        <div id="header_image">
            <div id="profile_name">
                <p id="name"><?php echo $res['name']?></p>
                <p id="email"><?php echo $res['email']?></p>
            </div>

        </div>
        <div id="first_part">
            <aside>
                <section id="contact">
                    <h2>Contacts</h2>
                    <div id="phone_no">
                        <i class="fas fa-phone-alt"></i>
                        <p id="position"><?php echo $res['position']?></p>
                    </div>
                    <div id="email">
                        <i class="fas fa-envelope"></i>
                        <p id="phone"><?php echo $res['phone']?></p>
                    </div>
                    <div id="facebook">
                        <i class="fab fa-facebook-square"></i>
                        <p>fb.com/design.kolomiets</p>
                    </div>
                    <div id="behance">
                        <i class="fab fa-behance-square"></i>
                        <p>behance.net/kolomiets</p>
                    </div>
                    <div id="location">
                        <i class="fas fa-map-marker-alt"></i>
                        <p>Warszawa</p>
                    </div>
                </section>

                <section id="skills">
                    <h2>Technical skills</h2>
                    <div class="sec">
                        <div id="photoshop">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/ps.png" alt="" class="icon">
                                <p>Photoshop</p>
                            </div>
                        </div>
                        <div id="illustrator">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/ai.png" alt="" class="icon">
                                <p>Illustrator</p>
                            </div>
                        </div>
                    </div>

                    <div class="sec">
                        <div id="Muse">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/mu.png" alt="" class="icon">
                                <p>Muse</p>
                            </div>
                        </div>
                        <div id="premiere">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/pr.png" alt="" class="icon">
                                <p>Premiere</p>
                            </div>
                        </div>
                    </div>

                    <div class="sec">

                        <div id="sketch">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/di.png" alt="" class="icon">
                                <p>Sketch</p>
                            </div>
                        </div>
                        <div id="coreldraw">
                            <div class="box">
                                <svg>
                                    <circle cx="30" cy="30" r="30"></circle>
                                    <circle cx="30" cy="30" r="30"></circle>
                                </svg>
                                <img src="images/pa.png" alt="" class="icon">
                                <p>corelDRAW</p>
                            </div>
                        </div>
                    </div>
                </section>
            </aside>
        </div>
        <div id="second_part">
            <section id="education">
                <h2>Education</h2>
                <p id="subject_or_group"><?php echo $res3['subject_or_group']?></p><br>
                <p id="Institute_name"><?php echo $res3['Institute_name']?></p><br>
                <p id="address"><?php echo $res3['address']?></p><br>
                <p id="date"><?php echo $res3['date']?></p><br>
                     </p>
            </section>
            <section id="language">
                <h2>Language</h2>
                <ul>
                    <li>
                        <p>Russian - C1</p>
                    </li>
                    <li>
                        <p>Ukrainian - C1</p>
                    </li>
                    <li>
                        <p>English - C1</p>
                    </li>
                </ul>
            </section>
            <section id="pro_skill">
                <h2>Professional Skills</h2>
                <ul>
                    <li>
                        <p>Able to organise own workload effectively and prioritise tasks.</p>
                    </li>
                    <li>
                        <p>Learning new technologies and keeping abreast of markets developments.</p>
                    </li>
                    <li>
                        <p>Having a passion for customer service & responding quickly to enquiries.</p>
                    </li>
                    <li>
                        <p>Can manage multiple projects in a fast-paced, deadline-driven environment.</p>
                    </li>
                    <li>
                        <p>Adaptable and able to quickly pick up new techniques.</p>
                    </li>
                    <li>
                        <p>Having creativity and imagination.</p>
                    </li>
                </ul>
            </section>
            <section id="personal_skill">
                <h2>Personal Skills</h2>
                <ul>
                    <li>
                        <p>Passionate about doing a good job. </p>
                    </li>
                    <li>
                        <p>First rate interpersonal and communication skills, able to easily interact with fellow
                            developers and customers alike.</p>
                    </li>
                    <li>
                        <p>Working to short lead times.</p>
                    </li>
                    <li>
                        <p>Confident, friendly and easy to get along with.</p>
                    </li>
            </section>
            <section id="work_experience">
                <h2>Work Experience</h2>
                <ul>
                    <li>
                        <p>
                            <p id="date"><?php echo $res2['date']?></p><br>
                            <p id="company_name"><?php echo $res2['company_name']?></p><br>
                            <p id="possition"><?php echo $res2['possition']?></p><br>
                            <p id="description"><?php echo $res2['description']?></p><br>
                        </p>
                    </li>
                </ul>
            </section>
        </div>
        <footer>
            <p>Wyrażam zgodę na przetwarzanie moich danych osobowych dla celów rekrutacji, zgodnie z ustawą z dnia 29
                sierpnia 1997 r. o ochronie danych osobowych (tj. Dz. U. Nr 101 z 2002 r., poz. 926 z późn. zm.).</p>
        </footer>
    </div>
</body>

</html>