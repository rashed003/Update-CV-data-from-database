<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Educational Information</title>
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$date = $_POST['date'];
    $subject_or_group = $_POST['subject_or_group'];
	$Institute_name = $_POST['Institute_name'];
	$address = $_POST['address'];
	$userId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($date) || empty($subject_or_group) || empty($Institute_name) || empty($address)) {
				
		if(empty($date)) {
			echo "<font color='red'>date field is empty.</font><br/>";
		}

        if(empty($subject_or_group)) {
			echo "<font color='red'>subject or group field is empty.</font><br/>";
		}
		
		if(empty($Institute_name)) {
			echo "<font color='red'>Institute name field is empty.</font><br/>";
		}
		
		if(empty($address)) {
			echo "<font color='red'>address field is empty.</font><br/>";
		}

		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO edu(date, subject_or_group, Institute_name, address, user_id) VALUES('$date','$subject_or_group','$Institute_name','$address','$userId')");
		
		//display success message
		echo "<br><font color='green'>Data added successfully.<br>";
	}
}
?>



	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="edu.php" method="post" name="form1">
		<table width="25%" border="0">
			<br><h2>Add educational Information</h2><br>
			<tr>
				<td>subject or group</td>
				<td><input type="text" name="subject_or_group"></td>
			</tr>
			<tr>
				<td>Institute name</td>
				<td><input type="text" name="Institute_name"></td>
			</tr>
			<tr>
				<td>address</td>
				<td><input type="text" name="address"></td>
			</tr>
             <tr>
				<td>date</td>
				<td><input type="date" name="date"></td>
			</tr>
            <tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
			
		</table>
        
	</form>



</body>
</html>