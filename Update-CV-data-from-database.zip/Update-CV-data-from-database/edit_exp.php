<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['update']))
{	
	$company_name = $_POST['company_name'];
    $date = $_POST['date'];
    $possition = $_POST['possition'];
	$description = $_POST['description'];
	$userId = $_SESSION['id'];
	
	// checking empty fields
	if(empty($company_name) || empty($date) || empty($possition) || empty($description)) {
				
		if(empty($company_name)) {
			echo "<font color='red'>company name field is empty.</font><br/>";
		}
		
		if(empty($date)) {
			echo "<font color='red'>date field is empty.</font><br/>";
		}
		
		if(empty($possition)) {
			echo "<font color='red'>possition field is empty.</font><br/>";
		}
        if(empty($description)) {
			echo "<font color='red'>description field is empty.</font><br/>";
		}		
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE exp SET company_name='$company_name', date='$date', possition='$possition', description='$description', WHERE id='$userId'");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: view_exp.php");
	}
}
?>
<?php
//getting id from url
$userId = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM exp WHERE id=$userId");

while($res = mysqli_fetch_array($result))
{
	$company_name = $res['company_name'];
	$date = $res['date'];
	$possition = $res['possition'];
    $description = $res['description'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	
	<form name="form1" method="post" action="edit_exp.php">
		<table border="0">
			<tr> 
				<td>company name</td>
				<td><input type="text" name="company_name" value="<?php echo $company_name;?>"></td>
			</tr>
			<tr> 
				<td>date</td>
				<td><input type="date" name="date" value="<?php echo $date;?>"></td>
			</tr>
			<tr> 
				<td>possition</td>
				<td><input type="text" name="possition" value="<?php echo $possition;?>"></td>
			</tr>
            <tr> 
				<td>description</td>
				<td><input type="text" name="description" value="<?php echo $description;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
